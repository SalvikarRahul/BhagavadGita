﻿using System.Diagnostics;

namespace ConsoleApp2
{
    internal class ProcessInfo
    {
        public static string ExecuteCommand(string command)
        {
            var processInfo = new ProcessStartInfo("cmd.exe", $"/c {command}")
            {
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
                WorkingDirectory = Directory.GetCurrentDirectory(), 
            };

            using (var process = new Process { StartInfo = processInfo })
            {
                process.Start();
                string output = process.StandardOutput.ReadToEnd();
                string error = process.StandardError.ReadToEnd();
                process.WaitForExit();
                if (!string.IsNullOrEmpty(error))
                {
                    output += $"\nError: {error}";
                }
                return output;
            }
        }

        public static void ConstrictHTL(List<Prs> PrList)
        {

            if (PrList.Count > 0)
            {

            }
        }
    }
}
